﻿
using var game = new Assignment3.Assignment3();
game.Run();
